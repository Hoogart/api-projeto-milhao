from fastapi import APIRouter
from app.services.analisador import gerar_sugestoes_avancado

router = APIRouter()

@router.get("/")
def sugestoes(mercado: str = None, min_odd: float = 1.5, time: str = None):
    return gerar_sugestoes_avancado(mercado, min_odd, time)